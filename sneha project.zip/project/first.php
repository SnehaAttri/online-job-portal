<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="bootstrap-4.5.2-dist\css" rel="stylesheet" type="text/css">
        <link href="bootstrap-4.5.2-dist\js" rel="stylesheet" type="text/js">
        <link rel="stylesheet" href="bootstrap-4.5.2-dist\css\bootstrap.min.css">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
body h1{ text-align: center;color:#4CAF50;}
form {border: 3px solid #f1f1f1;}

input[type=text ] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

input[type=password ] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
  magic_quotes_runtime:55px;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
  padding:10px ;
}

img.avatar {
  width: 100px;
  height: 150px;
  border-radius: 20%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn { 
     width: 100%;
  }
}
</style>
</head>
<body>
<?php
if(isset($_REQUEST["status"]))
{
  if($_REQUEST["status"]==1)
  {
    echo "<h6 style=float:right;color:#239B56 ;><i>Your Data Has Been Submitted</i></h6>";
  }
}
?>
<div class=container>
<h1>Online JOB PORTAL </h1></div>

<form action="login.php" method="post">
  <div class="imgcontainer">
    <img src="image/Emblem.jpeg" alt="Avatar" class="avatar">
  </div>

  <div class="container">
    <label for="name"><b>E-Mail</b></label>
    <input type="text" placeholder="Enter Your Email" name="text_Mail" required>

    <label for="pnum"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" required>
        
    <button type="submit" name="login">Login</button>
    <br>
    
    <label>
      <input type="checkbox" checked="checked" name="remember"> Remember me
    </label>
  </div>
</form>
<div class="container">
  <a href="user.html"><button type="button" name="signup">Sign-up/New Registeration</button></a></div>

  <div class="container" style="background-color:#f1f1f1">
    <button type="button" class="cancelbtn">Cancel</button>
    <span class="psw">Forgot <a href="#">password?</a></span>
  </div>


</body>
</html>
