<?php
   $t_mail=$_REQUEST["text_Mail"];
   $t_Password=$_REQUEST["password"];
   $t_name=$_REQUEST["f_Name"];
   $t_lname=$_REQUEST["l_Name"];
   $t_phone=$_REQUEST["phone"];
   $t_district=$_REQUEST["district"];
   $t_age=$_REQUEST["age"];
   $t_gender=$_REQUEST["gender"];

   $Photo=$_FILES["photo"]["name"];
   $tempname=$_FILES["photo"]["tmp_name"];
   $attach_Photo="fatch/".$Photo;
   move_uploaded_file($tempname,$attach_Photo);


   $Ac=$_FILES["ac"]["name"];
   $tempname=$_FILES["ac"]["tmp_name"];
   $attach_Ac="fatch/".$Ac;
   move_uploaded_file($tempname,$attach_Ac);


   $Ten=$_FILES["ten"]["name"];
   $tempname=$_FILES["ten"]["tmp_name"];
   $attach_Ten="fatch/".$Ten;
   move_uploaded_file($tempname,$attach_Ten);


   $Twelve=$_FILES["twelve"]["name"];
   $tempname=$_FILES["twelve"]["tmp_name"];
   $attach_Twelve="fatch/".$Twelve;
   move_uploaded_file($tempname,$attach_Twelve);


   $Grad=$_FILES["grad"]["name"];
   $tempname=$_FILES["grad"]["tmp_name"];
   $attach_Grad="fatch/".$Grad;
   move_uploaded_file($tempname,$attach_Grad);

   $t_no=$_REQUEST["SrNo"];
  
    include("connection.php");
    mysqli_query($con,"update user set  E_mail='$t_mail',Password='$t_Password', F_name='$t_name',L_name='$t_lname',phone_Number='$t_phone',Dst='$t_district',Age='$t_age',Gender='$t_gender',Photo='$attach_Photo',A_card='$attach_Ac',Tenth='$attach_Ten',P_two='$attach_Twelve',Grad='$attach_Grad' where SrNo=$t_no")or die("error in query");
    header("location:student.php");
?>