-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2021 at 10:50 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `major`
--

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `news_Id` int(11) NOT NULL,
  `content` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`news_Id`, `content`) VALUES
(1, 'SUB-INSPECTOR IN DELHI POLICE Examination, 2021'),
(2, 'Phase-VIII/2020/Selection Posts'),
(4, 'Uploading of final marks of Combined Graduate Level Examination'),
(19, 'patwari'),
(20, 'patwari'),
(21, 'Bank Po'),
(22, 'CDA'),
(23, 'NDA'),
(24, 'AUTOCAD'),
(25, 'Shiksha Karmi'),
(26, 'HPKVn'),
(28, 'uco bank'),
(29, ''),
(30, ''),
(31, 'cdac mohali');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `SrNo` int(11) NOT NULL,
  `Password` varchar(30) NOT NULL,
  `E_mail` varchar(30) NOT NULL,
  `F_name` varchar(20) NOT NULL,
  `L_name` varchar(20) NOT NULL,
  `Dst` varchar(20) NOT NULL,
  `Age` int(11) NOT NULL,
  `Gender` varchar(6) NOT NULL,
  `Photo` varchar(250) NOT NULL,
  `A_card` text NOT NULL,
  `Tenth` text NOT NULL,
  `P_two` text NOT NULL,
  `Grad` text NOT NULL,
  `phone_Number` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`SrNo`, `Password`, `E_mail`, `F_name`, `L_name`, `Dst`, `Age`, `Gender`, `Photo`, `A_card`, `Tenth`, `P_two`, `Grad`, `phone_Number`) VALUES
(110, '333', 'vikas@gmail.com', 'Vikas', 'Singh', 'kangra', 22, 'male', 'fatch/sumit  photo.jpg', 'fatch/sumit f.jpeg', 'fatch/IMG_20180821_171649948.jpg', 'fatch/IMG_20180821_171720801.jpg', 'fatch/sumit sign.jpg', 8580844402),
(113, '420', 'sumit@gmail.com', 'sumit', 'ranot', 'shimla', 23, 'male', 'fatch/sumit  photo.jpg', 'fatch/sumit f.jpeg', 'fatch/IMG_20180821_171720801.jpg', 'fatch/IMG_20180821_171649948.jpg', 'fatch/sumit sign.jpg', 7018097517),
(117, '987', 'naveen@gmail.com', 'Naveen', 'thakur', 'shimla', 23, 'male', 'fatch/sumit  photo.jpg', 'fatch/sumit f.jpeg', 'fatch/IMG_20180821_171720801.jpg', 'fatch/IMG_20180821_171649948.jpg', 'fatch/nielit.jpeg', 987654323);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`news_Id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`SrNo`),
  ADD UNIQUE KEY `phone_Number` (`phone_Number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `news_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `SrNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=118;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
