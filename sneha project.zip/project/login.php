<?php session_start();
$text_Email=$_REQUEST["text_Mail"];
$_SESSION["KD"]=$text_Email;

$Password=$_REQUEST["password"];
include("connection.php");
$rs=mysqli_query($con,"select * from user where  E_mail='$text_Email'") or die("error in query");
if(mysqli_num_rows($rs)==0)
{
    echo "<script>alert('Wrong E-mail Entered');</script>";
        echo "<a href='first.php'>Back to Login Page</a>";
    }

else{
    $row=mysqli_fetch_array($rs);
    if($row["Password"]==$Password)
    {
          header("location:student.php");
    }
    else
    {
        echo "<script>alert('Wrong Password Entered');</script>";
        echo "<a href='first.php'>Back to Login Page</a>";
    }
}
?>