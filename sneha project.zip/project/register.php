<?php
$text_Email=$_REQUEST["text_Mail"];
$text_Password=$_REQUEST["pwd"];
$f_Name=$_REQUEST["f_Name"];
$l_Name=$_REQUEST["l_Name"];
$Phone=$_REQUEST["Phone"];
$District=$_REQUEST["District"];
$Age=$_REQUEST["Age"];
$gender=$_REQUEST["Gender"];
//--------------PHOTO UPDATE-------------------//
$Photo=$_FILES["Photo"]["name"];
$tempname=$_FILES["Photo"]["tmp_name"];
$attach_Photo="fatch/".$Photo;
move_uploaded_file($tempname,$attach_Photo);
//--------------Aadhar Card UPDATE-------------------//
$Ac=$_FILES["Ac"]["name"];
$tempname=$_FILES["Ac"]["tmp_name"];
$attach_Ac="fatch/".$Ac;
move_uploaded_file($tempname,$attach_Ac);
//--------------Tenth Certificate UPDATE-------------------//

$Ten=$_FILES["Ten"]["name"];
$tempname=$_FILES["Ten"]["tmp_name"];
$attach_Ten="fatch/".$Ten;
move_uploaded_file($tempname,$attach_Ten);
//--------------Plus Two Certificate UPDATE-------------------//
$Twelve=$_FILES["Twelve"]["name"];
$tempname=$_FILES["Twelve"]["tmp_name"];
$attach_Twelve="fatch/".$Twelve;
move_uploaded_file($tempname,$attach_Twelve);
//--------------Graduation Certificate UPDATE-------------------//
$Grad=$_FILES["Grad"]["name"];
$tempname=$_FILES["Grad"]["tmp_name"];
$attach_Grad="fatch/".$Grad;
move_uploaded_file($tempname,$attach_Grad);

include("connection.php");
mysqli_query($con,"insert into user(E_mail,Password,F_name,L_name,phone_Number,Dst,Age,Gender,Photo,A_card,Tenth,P_two,Grad) values('$text_Email','$text_Password','$f_Name','$l_Name','$Phone','$District','$Age','$gender','$attach_Photo','$attach_Ac','$attach_Ten','$attach_Twelve','$attach_Grad')") or die("error in query");
header("location:first.php?status=1");
?>