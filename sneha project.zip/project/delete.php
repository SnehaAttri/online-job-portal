<?php
     $id=$_REQUEST["Stud"];
   include("connection.php");
    
   mysqli_query($con,"delete from user where SrNo='$id' ");
   header("location:admin.php");
?>