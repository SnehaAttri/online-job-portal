<!doctype html>
<html >
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>Govt. Job</title>
        <link href="bootstrap-4.5.2-dist\css" rel="stylesheet" type="text/css">
        <link href="bootstrap-4.5.2-dist\js" rel="stylesheet" type="text/js">
        <link rel="stylesheet" href="bootstrap-4.5.2-dist\css\bootstrap.min.css">
        <link type="text/css" href="style.css" rel="stylesheet">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        </head>

<!--header-->        
    <section class="header parent">
        <div class="container heading">
            <div class="row">
           
            <div class="col-md-12">
                <h1>STAFF SELECTION APPLICATION FORM </h1>
                <p> <h3>(Goverenment of India) </h3> </p>
            </div>
            
            </div>
        </div>
       
<hr>
    </section>
<?php
            error_reporting(0);
            $update=$_REQUEST['updateId'];
           
            include("connection.php");  
            $rs=mysqli_query($con,"select * from user where SrNo='$update'") or die("error in query");         
            $row=mysqli_fetch_array($rs);
            
            $id=$row["SrNo"];
            $text_Email=$row["E_mail"];
            $text_Password=$row["Password"];
            $f_Name=$row["F_name"];
            $l_Name=$row["L_name"];
            $Phone=$row["phone_Number"];
            $District=$row["Dst"];
            $Age=$row["Age"];
            $gender=$row["Gender"];

            $attach_Photo=$row["Photo"];

            $attach_Ac=$row["A_card"];

            $attach_Ten=$row["Tenth"];

            $attach_Twelve=$row["P_two"];

            $attach_Grad=$row["Grad"];
            
        ?>
        <div style="color: #4CAF50;" class="container">
        <form method="post" enctype="multipart/form-data" action="updateuser.php">
            <input type="hidden" name="SrNo" value="<?php echo $id;?>">
            <input type="hidden" name="text_Mail" value="<?php echo $text_Email;?>"><br><br>
            Enter your First Name <input type="text" name="f_Name" value="<?php echo $f_Name;?>"><br><br>
             Enter your Password <input type="number"  name="password" value="<?php echo $text_Password;?>"><br><br>
            Enter your Last name <input type="text" name="l_Name" value="<?php echo $l_Name; ?>"><br><br>
            Enter your Phone Number <input type="number" name="phone" value="<?php echo $Phone;?>"><br><br>
            Enter District <input type="text" name="district" value="<?php echo  $District;?>"><br><br>
            Enter Age <input type="number" name="age" value="<?php echo  $Age;?>"><br><br>
            Enter Gender <input type="text" name="gender" value="<?php echo $gender; ?>"><br><br>
            <!---->
            Attach Photo <input type="file" name="photo"><span style="color: red;"> Required to fill this</span> <img src="fatch/<?php echo $attach_Photo;?>" height='50' width='50' ><br><br>
            <!---->
            Attach Aadhar Card <input type="file" name="ac"><span style="color: red;"> Required to fill this</span> <img src="fatch/<?php echo $attach_Ac;?>" height='50' width='50' ><br><br>
            <!---->
            Attach matric <input type="file" name="ten"><span style="color: red;"> Required to fill this</span><img src="fatch/<?php echo $attach_Ten;?>" height='50' width='50' > <br><br>
            <!---->
            Attach plus two <input type="file" name="twelve"><span style="color: red;"> Required to fill this</span><img src="fatch/<?php echo $attach_Twelve;?>" height='50' width='50' >  <br><br>
             <!---->
            Attach Grad <input type="file" name="grad"><span style="color: red;"> Required to fill this</span> <img src="fatch/<?php echo $attach_Grad;?>" height='50' width='50' ><br><br>
            
            <button style="margin-left:520px; margin-bottom:30px;padding:4px;border-radius:10px;" type="submit" name="update" value="ok">update</button>
        </form>
        </div>
        <section class="footer" style="background-image:linear-gradient(#E7EBE0FF,#7DB46CFF); width:100%" >
                <div class="container ">
                <div class="row">
                    <div class="col-md-3">
                    <img src="image/flogo.png" class="footer_logo img-fluid">
                    <h5></h5><p></p>
                    </div>
                    <div class="col-md-9">
                    
                    </div>
                   
                    </div><hr>
                    <p class="copyright">Copyright &copy; All rights reserved | This template is made by<a href="https://www.instagram.com/sumitalonestar/"> Sumit & Vikas</a></p>
                </div>
                </section>
                
                </body>
                </html>