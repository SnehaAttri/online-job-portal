<?php
$con=mysqli_connect("127.0.0.1","root","");
mysqli_select_db($con,"major") or die("error in database selection");

?>
