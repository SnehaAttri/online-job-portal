<!doctype html>
<html >
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>Govt. Job</title>
        <link href="bootstrap-4.5.2-dist\css" rel="stylesheet" type="text/css">
        <link href="bootstrap-4.5.2-dist\js" rel="stylesheet" type="text/js">
        <link rel="stylesheet" href="bootstrap-4.5.2-dist\css\bootstrap.min.css">
        <link type="text/css" href="style.css" rel="stylesheet">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        </head>
<body>
<!--header-->        
    <section class="header parent">
        <div class="container heading">
            <div class="row">
           
            <div class="col-md-12">
                <h1>Online JOB PORTAL APPLICATION FORM </h1>
                <p> <h3>(Goverenment of India) </h3> </p>
            </div>
            
            </div>
        </div>
       
<hr>
    </section>
    <div class="container-fluid" style="height:100px;">
<?php session_start();
error_reporting(0);
include("connection.php");
 $rs=mysqli_query($con,"select * from user WHERE  E_mail='{$_SESSION['KD']}' ") or die("error in query");
 
 ///////////////////////////////////////////////// FATCHED DATA ///////////////////////////////////////////////////////////////////

 echo("<table border='1'align='center'>");
 echo("<tr style=background-color:#7DB46CFF;color:#E7EBE0FF;> <th width='70'> Reg. No.</th> <th width='70'> Password </th>  <th> E Mail </th> <th width='80'> First Name </th> <th width='80'> Last Name </th> <th> Phone Number </th> <th width='100'> District </th> <th width='50'> Age </th> <th width='50'> Gender </th> <th> Passport Photo </th> <th> Aadhar Card </th> <th> Tenth </th> <th> Plus Two </th> <th> Graduation </th></tr>");

 while($row=mysqli_fetch_array($rs))
   {
    echo("
            <div style=color:#4CAF50;background-color:#E7EBE0FF;>
                <h3>welcome $row[F_name] Employee number- $row[SrNo]</h3> 
            </div>
            ");
    echo "<tr>
         
    <td>
    $row[SrNo]
    </td>
    
    <td>
    $row[Password]
    </td>

       <td>
       $row[E_mail]
       </td>

       <td>
       $row[F_name]
       </td>

       <td>
       $row[L_name]
       </td>

       <td>
       $row[phone_Number]
       </td>

       <td>
       $row[Dst]
       </td>

       <td>
       $row[Age]
       </td>

       <td>
       $row[Gender]
       </td>

       <td>
       <img src='".$row[Photo]."'height='100' width='100'>
       </td>

       <td>
       <img src='".$row[A_card]."'height='100' width='100'>
       </td>

       <td>
       <img src='".$row[Tenth]."'height='100' width='100'>
       </td>

       <td>
       <img src='".$row[P_two]."'height='100' width='100'>
       </td>

       <td>
       <img src='".$row[Grad]."'height='100' width='100'>
       </td>
      ";
      
      $x=$row["SrNo"];
      
      echo("<button><a href='edit_user.php?updateId=$x'>Update</a></button>");
     
    }
    echo("</table>");


       ?>
       </div>


<div style="width:50% height:auto; margin-top:200px;;background-color:#E7EBE0FF; color:red;"><?php
$run_news=mysqli_query($con,"select * from news");
while($row=mysqli_fetch_array($run_news)){
    $e_news=$row['content'];
    echo"<div style='box-shadow: 0px 0px 8px 2px rgba(0,0,0,0.55);margin-right:auto;margin-left:auto;margin-top:2%;width:30%;height:auto;
    padding:5px 0px;backgound-color:white;'><img style='position:absolute;margin-left:-5px;margin-top:-20px;'
    src='image/new1.png' width='70' height='auto' align='left'><marquee scrollamount='2.5' style='font-weight:bold'><i>$e_news</i></marquee></div>";

}           
?>
</div>
<br><br>

<!--/////////////////////////////////////////////////////// FOOTER /////////////////////////////////////////////////////////-->
      <div style="background-image:linear-gradient(#E7EBE0FF,#7DB46CFF);text-align:center; padding:30px;" class="container-fluid ">
          <div class="row">
              <div class="container"> <p class="copyright">Copyright &copy; All rights reserved | This template is made by<a href="https://www.instagram.com/sumitalonestar/"> Sumit & Vikas</a></p>
          </div>
      </div>

                
                </body>
                </html>